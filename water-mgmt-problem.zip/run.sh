python -m geektrust ./sample/1.txt
python -m geektrust ./sample/2.txt
python -m geektrust ./sample/3.txt